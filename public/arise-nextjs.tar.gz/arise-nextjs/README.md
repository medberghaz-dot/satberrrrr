# Arise - Next.js Portfolio Website

موقع Arise - قالب وكالة عصري مبني بـ Next.js

## البدء السريع

### 1. تثبيت المتطلبات
تأكد من تثبيت Node.js على حاسوبك: https://nodejs.org

### 2. تثبيت المشروع

```bash
# انتقل إلى مجلد المشروع
cd arise-nextjs

# ثبت الحزم
pnpm install
# أو
npm install
```

### 3. تشغيل خادم التطوير

```bash
pnpm dev
# أو
npm run dev
```

ثم افتح المتصفح واذهب إلى: http://localhost:3000

## الصفحات المتاحة

- Home: http://localhost:3000
- Contact: http://localhost:3000/contact.html
- Blogs: http://localhost:3000/blogs.html
- Works: http://localhost:3000/works.html
- Waitlist: http://localhost:3000/waitlist.html

## المتطلبات

- Node.js 18+
- pnpm أو npm

---

تم إنشاؤها بـ Next.js 15 و React 18
